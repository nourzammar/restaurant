<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* CSS الخاص بتصميم صفحة تسجيل الدخول */

.login-form {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.card {
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

.card-header {
  background-color: #333;
  color: #fff;
  padding: 15px;
  font-size: 20px;
  text-align: center;
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}

.card-body {
  padding: 20px;
}

.form-group {
  margin-bottom: 15px;
}

.form-control {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.checkbox label {
  display: inline-block;
  font-weight: 400;
}

.btn-block {
  width: 100%;
}

.btn-dark {
  background-color: #333;
  color: #fff;
  border: none;
  padding: 10px 20px;
  font-size: 16px;
  cursor: pointer;
}

.text-danger {
  color: #ff0000;
}

    </style>
    <title>@yield('title')</title>
</head>
<body>
    <header>
        <!-- القائمة العلوية والشريط الجانبي وغيرها من العناصر الثابتة -->
    </header>

    <main>
        @yield('content')
    </main>

    <footer>
        <!-- التذييل وأي عناصر أخرى -->
    </footer>
</body>
</html>
