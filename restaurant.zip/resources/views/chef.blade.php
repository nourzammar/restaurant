<!DOCTYPE html>
<html>
<head>
    <title>واجهة الشيف في المطبخ</title>
    <link href="{{ asset('css/chef.css') }}" rel="stylesheet">
</head>
<body>
    <h1>Kitchen</h1>
    <h2> Raw Materials</h2>
    <div class="container">
        @if (session('message'))
        <script>
            alert("{{ session('message') }}");
        </script>
    @endif
        <form id="newMaterialForm" action="{{ route('chef.store') }}" method="post">
            @csrf
            <div id="nameFieldContainer">
                <label for="material1">Material Name:</label>
                <select id="material1" name="name">
                    @foreach ($items as $item)
                        <option value="{{ $item->name }}">{{ $item->name }}</option>
                    @endforeach
                </select>
            </div>
            <label for="weight1">Quantity:</label>
            <input type="text" id="weight1" name="quantity" required>
            <br>
            <input type="submit" value="Save">
        </form>

        <table>
            <tr>
                <th>Material Name</th>
                <th>Quantity</th>
            </tr>
            @php
                $addedItems = collect($addedItems);
                $quantities = [];
            @endphp
            @foreach ($addedItems as $addedItem)
                @php
                    $itemName = $addedItem['name'];
                    $quantity = is_numeric($addedItem['quantity']) ? $addedItem['quantity'] : 0;
                    if (isset($quantities[$itemName])) {
                        $quantities[$itemName] += $quantity;
                    } else {
                        $quantities[$itemName] = $quantity;
                    }
                @endphp
            @endforeach
            @foreach ($quantities as $itemName => $totalQuantity)
                <tr>
                    <td>{{ $itemName }}</td>
                    <td>{{ $totalQuantity }}</td>
                </tr>
            @endforeach
        </table>
    </div>
</body>
</html>
