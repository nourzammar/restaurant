<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>ORDER</title>

 
    <link href="{{ asset('css/dashboard/index.css') }}" rel="stylesheet" >

    <style>
        /* Styling for the aside container */
.menu-sidebar {
  background-color: #1a3a52;
  width: 250px;
  height: 100%;
  color: #ffffff;
}

/* Styling for the logo */
.logo {
  padding: 20px;
}

.logo img {
  width: 80px;
}

/* Styling for the navigation links */
.navbar__list {
  padding: 0;
  list-style: none;
}

.navbar__list li {
  margin: 0;
}

.navbar__list a {
  display: block;
  color: wheat;
  padding: 15px 20px;
  text-decoration: none;
  transition: background-color 1s ease;
}

.navbar__list a i {
  margin-right: 10px;
}

/* Hover effect for the links */
.navbar__list a:hover {
  background-color: wheat;
}

/* Submenu styles (if needed) */
.has-sub {
  position: relative;
}

.has-sub .js-arrow::after {
  content: '\f107';
  font-family: 'Font Awesome 5 Free';
  font-weight: 900;
  position: absolute;
  right: 20px;
}

.has-sub.active .js-arrow::after {
  content: '\f106';
}

/* Scrollbar styles for the sidebar content */
.menu-sidebar__content {
  overflow-y: auto;
  max-height: calc(100vh - 100px); /* Adjust this value as needed */
}

/* Additional styles for the table */
.table {
  width: 100%;
}

/* Styling for table header */
.table thead th {
  background-color: #1a3a52;
  color: #ffffff;
  padding: 10px;
}

/* Styling for table rows */
.table tbody td {
  padding: 10px;
}

/* Alternate row background color */
.table tbody tr:nth-child(even) {
  background-color: #f2f2f2;
}

/* Right-align text in specific columns */
.table tbody .text-right {
  text-align: right;
}

    </style>
   
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
           
            <div class="menu-sidebar__content js-scrollbar1">
              <nav class="navbar-sidebar">
                <ul class="list-unstyled navbar__list">
                  
                  <li>
                      <a href="DashRes">
                          <i class="fas fa-map-marker-alt"></i>RESERVATION</a>
                  </li>
                  <li>
                    <a href="DashOrder">
                      <i class="fas fa-table"></i>ORDER</a>
                    </li>
                    <li>
                      <a href="DashMeal">
                        <i class="fas fa-calendar-alt"></i>MEAL</a>
                      </li>
                      <li>
                          <a href="DashUser">
                              <i class="fas fa-chart-bar"></i>USER</a>
                      </li>
                        <li>
                            <a href="DashWare">
                                <i class="far fa-check-square"></i>WAREHOUSE</a>
                        </li>
                        
                        
                   
                      
                    </ul>
                </nav>
            </div>
        </aside>
     
        <div class="page-container">
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        
                                <div class="table-responsive table--no-card m-b-30">
                                  <table class="table table-borderless table-striped table-earning">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Order ID</th>
                                            <th>User Name</th>
                                            <th class="text-center">Sub Total</th>
                                            <th class="text-center">Tax</th>
                                            <th class="text-center">Grand Total</th>
                                            <th class="text-center">Button</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($data2 as $data)
                                       
                                        <td>{{ $data['order']->created_at}}</td>
                                        <td>{{ $data['order']->orders_id }}</td>
                                        <td>{{ $data['user']->name }}</td>
                                        <td>{{ $data['total'] }}</td>
                                        <td>{{ $data['tax'] }}</td>
                                        <td>{{ $data['totalTax'] }}</td>
                                        <td>
                                          <a href="{{ route('DashBill', ['bill'=>$data['bill']->bills_id]) }}" class="btn btn-sm btn-primary view-btn">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                                <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                            </svg>
                                        </a>
                                        </td>
                                      </tbody>
                                        @endforeach
                                </table>
                                            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
                        