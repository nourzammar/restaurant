<?php

namespace App\Http\Controllers;
use App\Models\Reservation;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReservationController extends Controller
{
    
    public function index()
    {
        $users = Auth::user();

        return view('index', ['users' => $users]);
    }

    public function store(Request $request)
    {
        // // حفظ اسم صاحب الحجز في جدول users_model
        // $users = new User();
        // $users->id = $request->id;
        // $users->name = !empty($request->name) ? $request->name : 'اسم غير معروف'; // التحقق من صحة الحقل 'name'
        
        // $users->email = $request->email;
        // $users->password = $request->password;
        // $users->save();
        
        $user = Auth::user();
        // // فظ بيانات الحجز في جدول reservations
        $reservation = new Reservation();
        $reservation->user_id = $user->user_id; // استخدام معرف المستخدم المحفوظ
        $reservation->guest_number = $request->guest_number;
        $reservation->datetime = $request->datetime;
        $reservation->save();


    
        return redirect()->route('order.index');
    }
}