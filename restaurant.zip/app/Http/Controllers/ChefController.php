<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use App\Models\item;
use Illuminate\Http\Request;

class ChefController extends Controller
{
    public function index()
    {
        $items = item::all();
        $addedItems = Session::get('added_items', []);
       
        return view('chef', ['items' => $items, 'addedItems' => $addedItems]);
    }
    
    public function store(Request $request)
    {
        $itemName = $request->input('name');
        $itemQuantity = $request->input('quantity');
    
        $item = Item::where('name', $itemName)->first();
    
        if ($item) {
            // Check if the requested quantity is less than or equal to the available quantity
            if (is_numeric($itemQuantity)) {
                if ($itemQuantity <= $item->quantity) {
                    $item->quantity -= $itemQuantity;
                    $item->save();
    
                    $addedItems = Session::get('added_items', []);
                    $addedItems[] = [
                        'name' => $itemName,
                        'quantity' => $itemQuantity
                    ];
                    Session::put('added_items', $addedItems);
    
                    return redirect()->route('chef.index');
                } else {
                    // Display a flash message indicating insufficient quantity
                    $message = 'There Is No Enough Quantity.';
                    return redirect()->route('chef.index')->with('message', $message);
                }
            } else {
                // Display a flash message indicating an invalid quantity
                $message = 'Quantity Value Is Invalid';
                return redirect()->route('chef.index')->with('message', $message);
            }
        } else {
            // Display a flash message indicating item not found
            $message = 'The Material Is Not Exists';
            return redirect()->route('chef.index')->with('message', $message);
        }
    }
}    