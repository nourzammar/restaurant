<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\bill;
use App\Models\BillMeal;
use App\Models\meal;
use App\Models\User;
use Illuminate\Http\Request;

class DashBillController extends Controller
{
    public function index($id)
    {
        $bills = BillMeal::where('bills_id' , $id)->get();
        $meals = [];
        foreach ($bills as $bill)
        {
            $mealName = meal::where('meal_id' , $bill->meal_id)->first();
            $data = [
                'billMeal' => $bill,
                'meal' => $mealName,
            ];
            array_push($meals , $data);
        }
        return view('dashboard.bill' , compact('meals'));
    }
    public function GetBillData()
    {
        $bills = bill::all();
        return view('dashboard.bill' ,[
            'bills' => $bills,
        ]);
    
    }
}
