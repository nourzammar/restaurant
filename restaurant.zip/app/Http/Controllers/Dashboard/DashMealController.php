<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Item;
use App\Models\meal;
use Illuminate\Http\Request;

use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DashMealController extends Controller
{
    public function index()
    {
        $meals = meal::with('media')->get();
        return view('dashboard.meal' , compact('meals'));
    }
    public function GetOrderData()
    {
        $meals = meal::all();
        return view('dashboard.meal' ,[
            'meals' => $meals,
        ]);
    }
    public function edit($id)
    {
        $EditMeals = meal::with('items')->find($id);
        $items = $EditMeals->items;
        $allItems = Item::all();
        return view('dashboard.EditMeal', compact('EditMeals' , 'items' , 'allItems'));
    }
    
    // public function update(Request $request, $id)
    // {
    //     // Validate the form data
    //     $request->validate([
    //         'name' => 'required|string|max:255',
    //         'price' => 'required|numeric',
    //         // Add more validation rules for other attributes as needed
    //     ]);
    
    //     // Find the meal record to be updated
    //     $meal = meal::find($id);
    
    //     // Update the meal attributes with the new values from the form
    //     $meal->name = $request->input('name');
    //     $meal->price = $request->input('price');
    //     // Update other attributes here
    
    //     // Save the changes to the database
    //     $meal->save();
    
    //     // Redirect to the meal listing page with a success message
    //     return redirect()->route('meal.index')->with('success', 'Meal updated successfully.');
    // }
    
}
