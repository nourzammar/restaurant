<h1>MEALS</h1>
<form method="POST" action="<?php echo e(route('meal.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <input type="text" name="id" placeholder="enter your id"> <br><br>
  <input type="text" name="name"><br> <br>
  <input type="text" name="price"><br> <br>
  <input type="text" name="item1"><br><br>
  <input type="text" name="item2"><br><br>
  <input type="text" name="item3"><br><br>
  <input type="text" name="item4"><br><br>
  <input type="text" name="item5"><br><br>
  <select name="type">
    <option value="main_course">Main Meal </option>
    <option value="appetizer">appetizer</option>
    <option value="drink">drink</option>
  </select><br><br>
  <input type="file" name="photo" accept="image/*" capture="camera"><br><br>

  <button type="submit">submit  </button>
</form><?php /**PATH D:\Laravel\restaurant\resources\views/meal.blade.php ENDPATH**/ ?>