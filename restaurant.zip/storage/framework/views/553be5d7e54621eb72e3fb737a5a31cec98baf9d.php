<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
  
  <title>Login & Registration Form</title>
</head>
<body style="background-image: url(images/wood_1.png)">

   
  <div class="container">
    <input type="checkbox" id="check">
    <div class="login form">
      <header>Login</header>
      <form action=" <?php echo e(route('CustomAuth.login')); ?>" method="POST"  >
        <?php echo csrf_field(); ?>
        <input type="text" name="email" placeholder="Enter your email">
        <input type="password"name="password" placeholder="Enter your password">
        <button type="submit" class="sub">LogIN</button>
      </form>
      <div class="signup">
        <span class="signup">Don't have an account?
         <label for="check">Signup</label>
        </span>
      </div>
    </div>
    <div class="registration form">
      <header>Signup</header>
      <form action=" <?php echo e(route('CustomAuth.register')); ?>" method="POST"  >
        <?php echo csrf_field(); ?>
        <input type="name" name="name" placeholder="Enter your name">
        <input type="email" name="email" placeholder="Enter your email">
        <input type="password" name="password" placeholder="Create a password">
        <button type="submit" class="sub">SIGNUP</button>
      </form>
      <div class="signup">

        <span class="signup">Already have an account?
         <label for="check">Sign in</label>
        </span>
      </div>
    </div>
  </div>

</body>
</html>
<?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/auth/login.blade.php ENDPATH**/ ?>