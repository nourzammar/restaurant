<!DOCTYPE html>
<html>
<head>
    <title>واجهة الشيف في المطبخ</title>
    <link href="<?php echo e(asset('css/chef.css')); ?>" rel="stylesheet">
</head>
<body>
    <h1>Kitchen</h1>
    <h2> Raw Materials</h2>
    <div class="container">
        <?php if(session('message')): ?>
        <script>
            alert("<?php echo e(session('message')); ?>");
        </script>
    <?php endif; ?>
        <form id="newMaterialForm" action="<?php echo e(route('chef.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div id="nameFieldContainer">
                <label for="material1">Material Name:</label>
                <select id="material1" name="name">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <label for="weight1">Quantity:</label>
            <input type="text" id="weight1" name="quantity" required>
            <br>
            <input type="submit" value="Save">
        </form>

        <table>
            <tr>
                <th>Material Name</th>
                <th>Quantity</th>
            </tr>
            <?php
                $addedItems = collect($addedItems);
                $quantities = [];
            ?>
            <?php $__currentLoopData = $addedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $itemName = $addedItem['name'];
                    $quantity = is_numeric($addedItem['quantity']) ? $addedItem['quantity'] : 0;
                    if (isset($quantities[$itemName])) {
                        $quantities[$itemName] += $quantity;
                    } else {
                        $quantities[$itemName] = $quantity;
                    }
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $quantities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemName => $totalQuantity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($itemName); ?></td>
                    <td><?php echo e($totalQuantity); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/chef.blade.php ENDPATH**/ ?>