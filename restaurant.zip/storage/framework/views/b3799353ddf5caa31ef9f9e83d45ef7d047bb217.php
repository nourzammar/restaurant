<!DOCTYPE html>
<html>
<head>
  <title>قائمة الوجبات</title>
  
  <link href="<?php echo e(asset('css/order.css')); ?>" rel="stylesheet">
</head>
<body>
   <h1>Menu</h1>
  <h2>Main Meals</h2>
  <form method="POST" action="<?php echo e(route('dineout.store')); ?>" onsubmit="return validateForm()">
    <?php echo csrf_field(); ?>
  
    <div class="meal-container">
      
      <?php $__currentLoopData = $mainCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="meal" onclick="selectMeal(this)" data-id="<?php echo e($meal->meal_id); ?>">

        <div>
          <img src="<?php echo e($meal->getFirstMediaUrl()); ?>" alt="صورة الوجبة">
        </div>
        <h3><?php echo e($meal->name); ?></h3>
        <p>Ingredients: <?php echo e($meal->item1); ?> <?php echo e($meal->item2); ?> <?php echo e($meal->item3); ?> <?php echo e($meal->item4); ?> <?php echo e($meal->item5); ?></p>
        <p>Price: <?php echo e($meal->price); ?></p>
        <input type="number" name="quantity[]" min="1" max="10" value="1" style="display: none;">
        <input type="hidden" name="selected_meals[]" value="<?php echo e($meal->meal_id); ?>">   
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h2>Appetizers</h2>
    <div class="meal-container">
      <?php $__currentLoopData = $appetizers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="meal" onclick="selectMeal(this)" data-meal-id="<?php echo e($meal->meal_id); ?>">

        <div>
          <img src="<?php echo e($meal->getFirstMediaUrl()); ?>" alt="صورة الوجبة">
        </div>
        <h3><?php echo e($meal->name); ?></h3>
        <p>Ingredients: <?php echo e($meal->item1); ?> <?php echo e($meal->item2); ?> <?php echo e($meal->item3); ?> <?php echo e($meal->item4); ?> <?php echo e($meal->item5); ?></p>
        <p>Price: <?php echo e($meal->price); ?></p>
        <input type="number" name="quantity[]" min="1" max="10" value="1" style="display: none;">
        <input type="hidden" name="selected_meals[]" value="<?php echo e($meal->meal_id); ?>">
      
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <h2>Drinks</h2>
    <div class="meal-container">
      <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="meal" onclick="selectMeal(this)" data-meal-id="<?php echo e($meal->meal_id); ?>">
        <div>
        <img src="<?php echo e($meal->getFirstMediaUrl()); ?>" alt="صورة الوجبة">
        </div>
        <h3><?php echo e($meal->name); ?></h3>
        <p>Ingredients: <?php echo e($meal->item1); ?> <?php echo e($meal->item2); ?> <?php echo e($meal->item3); ?> <?php echo e($meal->item4); ?> <?php echo e($meal->item5); ?></p>
        <p>Price: <?php echo e($meal->price); ?></p>
        <input type="number" name="quantity[]" min="1" max="10" value="1" style="display: none;">
        <input type="hidden" name="selected_meals[]" value="<?php echo e($meal->meal_id); ?>">
       
        </select>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 
    <div class="order-time-container">
      <label for="order_time">Order Time:</label>
      <input type="time" id="order_time" name="order_time">
    </div>  
    <button type="submit" class="submit-button">Send Order</button>
  </form>
  <script>
  function selectMeal(meal) {
    meal.classList.toggle('selected');
    
    // Toggle display of quantity and order type fields
    var quantityField = meal.querySelector('input[name="quantity[]"]');
  
    
    if (meal.classList.contains('selected')) {
      meal.style.border = '2px solid orange'; // Add orange border
      quantityField.style.display = 'block';
     
    } else {
      meal.style.border = 'none'; // Remove border
      quantityField.style.display = 'none';
      
    }
    console.log(quantityField);
  }
  
  // Prevent click events on quantity and order type fields from propagating further
  var quantityFields = document.querySelectorAll('input[name="quantity[]"]');

  
  quantityFields.forEach(function(field) {
    field.addEventListener('click', function(event) {
      event.stopPropagation();
    });
  });
  

  function validateForm() {
  // Perform any form validation here if needed

  // Collect the selected meals
  var selectedMeals = [];
  var selectedMealElements = document.querySelectorAll('.meal.selected');

  if (selectedMealElements.length === 0) {
    alert('Please select at least one meal.');
    return false; // Prevent form submission
  }

  if (selectedMealElements.length === 1) {
    // Only one meal is selected, send its ID
    var mealId = selectedMealElements[0].getAttribute('data-meal-id');
    var quantity = selectedMealElements[0].querySelector('input[name="quantity[]"]').value;

    selectedMeals.push({
      mealId: mealId,
      quantity: quantity,
    });
  } else {
    selectedMealElements.forEach(function(mealElement) {
      var mealId = mealElement.getAttribute('data-meal-id');
      var quantity = mealElement.querySelector('input[name="quantity[]"]').value;

      selectedMeals.push({
        mealId: mealId,
        quantity: quantity,
      });
    });
  }


  fetch('<?php echo e(route('order.store')); ?>', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    },
    body: JSON.stringify(selectedMeals)
  })
    .then(response => {
 
    })
    .catch(error => {
      // Handle any error that occurred during the request
      console.error('Error:', error);
    });

  // Allow form submission
  return true;
}
</script>
</body>
</html><?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/dineout.blade.php ENDPATH**/ ?>