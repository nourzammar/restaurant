

<h1>RESERVATIONS</h1>
<form method="POST" action="<?php echo e(route('reservations.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php

use Illuminate\Support\Facades\DB;

  $reservationId = DB::table('reservations')->orderByDesc('reservations_id')->value('reservations_id') + 1;
  $order = DB::table('reservations')->orderByDesc('orders_id')->value('orders_id') + 1;
  $user = DB::table('reservations')->orderByDesc('users_id')->value('users_id') + 1;
  ?>
  <input type="hidden" name="reservations_id" value="<?php echo e($reservationId); ?>">
  <input type="hidden" name="orders_id" value="<?php echo e($order); ?>">
  <input type="hidden" name="users_id" value="<?php echo e($user); ?>">
  
  <input type="number" name="guest_number"><br><br>
  <input type="text" name="table_number"><br><br>
  <input type="text" name="status" value ="Pending"><br><br>
  <input type="date" name="datetime"><br><br>
  <button type="submit">submit  </button>
</form>
<?php /**PATH D:\Laravel\restaurant\resources\views/reservation.blade.php ENDPATH**/ ?>