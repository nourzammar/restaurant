<!DOCTYPE html>
<html lang="en">

<head>
	<link href="<?php echo e(asset('css/dashboard/index.css')); ?>" rel="stylesheet" >
	<link rel="stylesheet" href="css/items.css">
	<script src="js/meal.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-/1EdIz35Quc/ksN4xMnq0FLkX7VMwGc+gk9UQQIzG8QVDoaR60UvmMWfm2L0UPy1tD2N6dVXj6g9yPTnzI4Q==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <style>
        /* Styling for the aside container */
        .menu-sidebar {
        background-color: #1a3a52;
        width: 250px;
        height: 100%;
        color: #ffffff;
        }
  
        /* Styling for the logo */
        .logo {
        padding: 20px;
        }
  
        .logo img {
        width: 80px;
        }
  
        /* Styling for the navigation links */
        .navbar__list {
        padding: 0;
        list-style: none;
        }
  
        .navbar__list li {
        margin: 0;
        }
  
        .navbar__list a {
        display: block;
        color: wheat;
        padding: 15px 20px;
        text-decoration: none;
        transition: background-color 1s ease;
        }
  
        .navbar__list a i {
        margin-right: 10px;
        }
  
        /* Hover effect for the links */
        .navbar__list a:hover {
        background-color: wheat;
        }
  
        /* Submenu styles (if needed) */
        .has-sub {
        position: relative;
        }
  
        .has-sub .js-arrow::after {
        content: '\f107';
        font-family: 'Font Awesome\ 5 Free';
        font-weight: 900;
        position: absolute;
        right: 20px;
        }
  
        .has-sub.active .js-arrow::after {
        content: '\f106';
        }
  
        /* Scrollbar styles for the sidebar content */
        .menu-sidebar__content {
        overflow-y: auto;
        max-height: calc(100vh - 100px); Adjust this value as needed
        }
        .btn-lg-blue {
        background-color: #1a3a52; /* Blue color */
        color: #ffffff; /* White text color */
        font-size: 18px; /* Larger font size */
        padding: 12px 24px; /* Larger padding */
        border-radius: 8px; /* Rounded corners */
    }

    /* Updated styles for the SVG icon */
    .svg-lg-blue {
        width: 24px; /* Larger width */
        height: 24px; /* Larger height */
        fill: #ffffff; /* White color */
        margin-right: 8px; /* Space between icon and text */}
     </style>
    <title>Tables</title>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
           
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            
            
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="DashRes">
                                <i class="fas fa-map-marker-alt"></i>RESERVATION</a>
                        </li>
                        <li>
                            <a href="DashOrder">
                                <i class="fas fa-table"></i>ORDER</a>
                            </li>
                            <li>
                                <a href="DashMeal">
                                    <i class="fas fa-calendar-alt"></i>MEAL</a>
                                </li>
                                <li>
                                    <a href="DashUser">
                                        <i class="fas fa-chart-bar"></i>USER</a>
                                    </li>
                                    <li>
                                        <a href="DashWare">
                                            <i class="far fa-check-square"></i>WAREHOUSE</a>
                                        </li>
                                    
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container" style="margin: 20ch">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
              
            </header>
         
            <div class="row">
                <div class="col-md-12">
                    <!-- DATA TABLE -->
                    <h3 class="title-5 m-b-35">DATA MEALS</h3>
                    <div class="table-data__tool">
                        <div class="table-data__tool-left">
                            <div class="dropDownSelect2"></div>
                        </div>
                    </div>
                </div>
            
                <div class="table-responsive table-responsive-data2">
                    <table class="table table-data2">
                        <thead>
                            <tr>
                                <th style="color: white">image</th>
                                <th style="color: white">meal name</th>
                                <th style="color: white">price</th>
                                <th style="color: white">type</th>
                                <th style="color: white">items</th>
                                <th style="color: white">actions</th> <!-- Add the new header for actions -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="tr-shadow" data-meal-id="<?php echo e($meal->meal_id); ?>"> <!-- Add data-meal-id attribute -->
                                    <td> <img src="<?php echo e($meal->getFirstMediaUrl()); ?>" alt="صورة الوجبة"></td>
                                    <td class="meal-name"><?php echo e($meal->name); ?></td>
                                    <td class="meal-price"><?php echo e($meal->price); ?></td>
                                    <td class="desc"><?php echo e($meal->type); ?></td>
                                    <td><?php echo e($meal->item1); ?><?php echo e($meal->item2); ?><?php echo e($meal->item3); ?><?php echo e($meal->item4); ?></td>
                                    <td>
                                        <!-- Edit button -->
                                        <a href="<?php echo e(route('meal.edit', ['id' => $meal->meal_id])); ?>" class="btn btn-sm btn-primary edit-btn">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                                <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                                            </svg>
                                        </a>
                                        
                        
                                        <!-- Delete button -->
                                        <a href="" class="btn btn-sm btn-danger">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
                                                <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
                                            </svg>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                        
                    </table>
                   
                    <!-- Add Meal button -->
                    <button id="addMealBtn" class="btn btn-lg-blue">
                        <svg xmlns="http://www.w3.org/2000/svg" class="svg-lg-blue" viewBox="0 0 16 16">
                            <path fill-rule="evenodd" d="M8 2a.5.5 0 0 1 .5.5v5h5a.5.5 0 0 1 0 1h-5v5a.5.5 0 0 1-1 0v-5h-5a.5.5 0 0 1 0-1h5v-5A.5.5 0 0 1 8 2Z"/>
                        </svg>
                       
                    </button>


                    <form method="POST" id="addMealForm" action="<?php echo e(route('meal.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
<div id="newMealModal" style="display: none;">
    <!-- Modal content -->
    <div>
        <h3>Add New Meal</h3>
            <label for="mealName">Name:</label>
            <input type="text" id="Name" name="mealName">
            <label for="mealPrice">Price:</label>
            <input type="number" id="price" name="mealPrice">
            <br>
            
            <button type="submit" id="addMealBtn" class="btn btn-lg-blue">SAVE MEAL</button>
       
    </div>
</div>
</form>

                </div>
            </div>
            
                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    
    
</body>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Define the meals variable
        const meals = <?php echo $meals->toJson(); ?>;
    
        // Get references to the button and modal
        const addMealBtn = document.getElementById("addMealBtn");
        const newMealModal = document.getElementById("newMealModal");
    
        // Handle the click event for the add meal button
        addMealBtn.addEventListener("click", function (event) {
            event.preventDefault();
            // Show the new meal modal
            newMealModal.style.display = "block";
        });
    
        // Handle the form submission for adding a new meal
        const addMealForm = document.getElementById("addMealForm");
        addMealForm.addEventListener("submit", function (event) {
            event.preventDefault();
            // Retrieve the form data
            const mealName = document.getElementById("Name").value;
            const mealPrice = document.getElementById("price").value;
            // ... Add other form fields if needed
    
            // Implement the logic to add the new meal (e.g., using Fetch API to send the data to your backend)
            fetch('<?php echo e(route('meal.store')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: mealName,
                    price: mealPrice,
                    // Add other properties as needed
                })
            })
            .then(response => response.json())
            .then(data => {
                // Handle the response, for example, update the table with the new meal data
                // Example:
                const newRow = document.createElement("tr");
                newRow.innerHTML = `
                    <td>...</td>
                    <td>${mealName}</td>
                    <td>${mealPrice}</td>
                    <td>...</td>
                    <td>...</td>
                    <td>
                        <a href="#" class="btn btn-sm btn-primary edit-btn">Edit</a>
                        <a href="#" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                `;
                // Add the new row to the table
                const tableBody = document.querySelector(".table-data2 tbody");
                tableBody.appendChild(newRow);
    
                // Close the modal after successful addition
                newMealModal.style.display = "none";
    
                // Clear the form fields after successful addition
                addMealForm.reset();
            })
            .catch(error => {
                // Handle errors if any
                console.error(error);
            });
        });
    });
</script>

    
<script>
      document.addEventListener("DOMContentLoaded", function () {
        // Define the meals variable
        const meals = <?php echo $meals->toJson(); ?>;
    document.addEventListener("DOMContentLoaded", function () {
        const editButtons = document.querySelectorAll(".edit-btn");
        const editModal = document.getElementById("editModal");
        const mealNameInput = document.getElementById("mealName");
        const mealPriceInput = document.getElementById("mealPrice");

        let selectedMealId;

        // Function to open the modal and populate it with the selected meal data
        function openEditModal(mealId) {
            // Find the meal data based on its ID (you can get this data from your backend)
            const selectedMeal = $meals.find(meal => meal.id === mealId);

            // Populate the input fields with the selected meal data
            mealNameInput.value = selectedMeal.name;
            mealPriceInput.value = selectedMeal.price;

            // Show the modal
            editModal.style.display = "block";
        }

        // Function to close the modal
        function closeEditModal() {
            editModal.style.display = "none";
        }

        // Handle click event for the edit buttons
        editButtons.forEach(button => {
            button.addEventListener("click", function (event) {
                event.preventDefault();
                selectedMealId = this.closest("tr").dataset.mealId;
                openEditModal(selectedMealId);
            });
        });

        // Save changes and close the modal
        const saveChangesBtn = document.getElementById("saveChangesBtn");
        saveChangesBtn.addEventListener("click", function () {
            // Get the edited values from the input fields
            const editedMealName = mealNameInput.value;
            const editedMealPrice = mealPriceInput.value;

            // Update the table data with the edited values
            const selectedRow = document.querySelector(`tr[data-meal-id="${selectedMealId}"]`);
            selectedRow.querySelector(".meal-name").textContent = editedMealName;
            selectedRow.querySelector(".meal-price").textContent = editedMealPrice;

            // Close the modal
            closeEditModal();
        });
    });
});
</script>

</html>
<!-- end document-->
<?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/dashboard/meal.blade.php ENDPATH**/ ?>