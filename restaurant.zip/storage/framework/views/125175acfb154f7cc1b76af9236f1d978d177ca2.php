<h1>USER</h1>
<form method="POST" action="<?php echo e(route('users.store')); ?> ">
  <?php echo csrf_field(); ?>
  <input type="text" name="users_id" placeholder="enter your id"> <br><br>
  <input type="text" name="name"><br> <br>
  <input type="text" name="phone"><br> <br>
  <input type="text" name="email"><br><br>
  <input type="text" name="password"><br><br>
  <button type="submit">submit  </button>
</form><?php /**PATH D:\Laravel\restaurant\resources\views/users.blade.php ENDPATH**/ ?>