<!DOCTYPE html>
<html lang="en">

<head>
	<link href="<?php echo e(asset('css/dashboard/index.css')); ?>" rel="stylesheet" >
	<link rel="stylesheet" href="css/items.css">
	<script src="js/meal.js"></script>

    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">
     <style>
        
            body, h1, h2, h3, h4, h5, h6, p, ul, li {
            margin: 0;
            padding: 0;
            }

            /* Set a background color */
            body {
            background-color: #e5e5e5;
            }

            /* Center the content vertically */
            .page-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            }

            /* Set the background color for the page container */
            .page-container {
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 8px;
            }

            /* Style the table */
            .table-data2 {
            width: 100%;
            border-collapse: collapse;
            }

            .table-data2 th, .table-data2 td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e5e5e5;
            }

            .table-data2 th {
            background-color: #1a3a52;
            color: #ffffff;
            }

            /* Style the title */
            .title-5 {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            }

            /* Style the links */
            a {
            color: #e5e5e5;
            text-decoration: none;
            }

          
                    /* Styling for the aside container */
        .menu-sidebar {
        background-color: #1a3a52;
        width: 250px;
        color: #e5e5e5
        
        }

      

        /* Styling for the navigation links */
        .navbar__list {
        padding: 0;
        list-style: none;
        }

        .navbar__list li {
        margin: 0;
        }
        .navbar__list a:hover {
        background-color: #e5e5e5;
        transition:  1s ;
        }

     
       


       
    </style>
    <title>Tables</title>

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
           
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="DashRes">
                                <i class="fas fa-map-marker-alt"></i>RESERVATION</a>
                        </li>
                        <li>
                            <a href="DashOrder">
                                <i class="fas fa-table"></i>ORDER</a>
                            </li>
                            <li>
                                <a href="DashMeal">
                                    <i class="fas fa-calendar-alt"></i>MEAL</a>
                                </li>
                                <li>
                                    <a href="DashUser">
                                        <i class="fas fa-chart-bar"></i>USER</a>
                                </li>
                    
                            <li>
                                <a href="DashWare">
                                    <i class="far fa-check-square"></i>WAREHOUSE</a>
                                </li>
                      
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container" style="margin: 20ch">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
              
            </header>
         
                        <div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">Data Reservations</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                 
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2" style="font-size: 100%">
                                        <thead >
                                            <tr >
                                              
                                                <th style="color: white">Customer</th>
                                                <th style="color: white">guest number</th>
                                                <th style="color: white">Reservation date</th>
                                             
                                             
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr >
                                                <td><?php echo e($reservation->users->name); ?></td>
                                                <td><?php echo e($reservation->guest_number); ?></td> 
                                                <td><?php echo e($reservation->datetime); ?></td>
                                               
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            
                                            
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>


</body>

</html>
<!-- end document-->
<?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/dashboard/reservation.blade.php ENDPATH**/ ?>