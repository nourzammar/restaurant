<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="au theme template">
	<meta name="author" content="Hau Nguyen">
	<meta name="keywords" content="au theme template">

	<!-- Title Page-->
	<title>Alert</title>


	<link href="<?php echo e(asset('css/dashboard/index.css')); ?>" rel="stylesheet" >
	<link href="<?php echo e(asset('css/dashboard/font-face.css')); ?>" rel="stylesheet" >
	<link href="<?php echo e(asset('css/dashboard/bootstrap.css')); ?>" rel="stylesheet" >
    <style>
        
    </style>

</head>

<body class="animsition">
	<div class="page-wrapper">
		
		<!-- END HEADER MOBILE-->

		<!-- MENU SIDEBAR-->
		<aside class="menu-sidebar d-none d-lg-block">
			<div class="logo">
				<a href="#">
					<img src="images/icon/logo.png" alt="Cool Admin" />
				</a>
			</div>
			<div class="menu-sidebar__content js-scrollbar1">
				<nav class="navbar-sidebar">
					<ul class="list-unstyled navbar__list">
						
						<li>
							<a href="DashUser">
								<i class="fas fa-chart-bar"></i>USER</a>
						</li>
						<li>
							<a href="DashOrder">
								<i class="fas fa-table"></i>ORDER</a>
						</li>
						<li>
							<a href="form.html">
								<i class="far fa-check-square"></i>Forms</a>
						</li>
						<li>
							<a href="calendar.html">
								<i class="fas fa-calendar-alt"></i>Calendar</a>
						</li>
						<li>
							<a href="map.html">
								<i class="fas fa-map-marker-alt"></i>Maps</a>
						</li>
						<li class="has-sub">
							<a class="js-arrow" href="main">
								<i class="fas fa-tachometer-alt"></i>BILL</a>
						
						</li>
						<li class="has-sub">
							<a class="js-arrow" href="#">
								<i class="fas fa-copy"></i>Pages</a>
							<ul class="list-unstyled navbar__sub-list js-sub-list">
								<li>
									<a href="login.html">Login</a>
								</li>
								<li>
									<a href="register.html">Register</a>
								</li>
								<li>
									<a href="forget-pass.html">Forget Password</a>
								</li>
							</ul>
						</li>
						
					</ul>
				</nav>
			</div>
		</aside>
		<!-- END MENU SIDEBAR-->

		<!-- PAGE CONTAINER-->
		<div class="page-container">
			<!-- HEADER DESKTOP-->
			<header class="header-desktop">
				
			</header>
			<!-- HEADER DESKTOP-->
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<div class="section__content section__content--p30">
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-6">

								<div class="card">
									<div class="card-header">
										<strong class="card-title">Alerts</strong>
									</div>
									<div class="card-body">
										<div class="alert alert-primary" role="alert">
											This is a primary alert—check it out!
										</div>
										<div class="alert alert-secondary" role="alert">
											This is a secondary alert—check it out!
										</div>
										<div class="alert alert-success" role="alert">
											This is a success alert—check it out!
										</div>
										<div class="alert alert-danger" role="alert">
											This is a danger alert—check it out!
										</div>
										<div class="alert alert-warning" role="alert">
											This is a warning alert—check it out!
										</div>
										<div class="alert alert-info" role="alert">
											This is a info alert—check it out!
										</div>
										<div class="alert alert-light" role="alert">
											This is a light alert—check it out!
										</div>
										<div class="alert alert-dark" role="alert">
											This is a dark alert—check it out!
										</div>
									</div>
								</div>

								<div class="card">
									<div class="card-header">
										<strong class="card-title">Link Color Alerts</strong>
									</div>
									<div class="card-body">
										<div class="alert alert-primary" role="alert">
											This is a primary alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-secondary" role="alert">
											This is a secondary alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-success" role="alert">
											This is a success alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-danger" role="alert">
											This is a danger alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-warning" role="alert">
											This is a warning alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-info" role="alert">
											This is a info alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-light" role="alert">
											This is a light alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
										<div class="alert alert-dark" role="alert">
											This is a dark alert with
											<a href="#" class="alert-link">an example link</a>. Give it a click if you like.
										</div>
									</div>
								</div>


							</div>


							<div class="col-md-6">

								<div class="card">
									<div class="card-header">
										<strong class="card-title">Dismissing Alerts</strong>
									</div>
									<div class="card-body">
										<div class="sufee-alert alert with-close alert-primary alert-dismissible fade show">
											<span class="badge badge-pill badge-primary">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-secondary alert-dismissible fade show">
											<span class="badge badge-pill badge-secondary">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
											<span class="badge badge-pill badge-success">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
											<span class="badge badge-pill badge-danger">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-warning alert-dismissible fade show">
											<span class="badge badge-pill badge-warning">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-info alert-dismissible fade show">
											<span class="badge badge-pill badge-info">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-light alert-dismissible fade show">
											<span class="badge badge-pill badge-light">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

										<div class="sufee-alert alert with-close alert-dark alert-dismissible fade show">
											<span class="badge badge-pill badge-dark">Success</span>
											You successfully read this important alert.
											<button type="button" class="close" data-dismiss="alert" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>

									</div>
								</div>

								<div class="card">
									<div class="card-header">
										<strong class="card-title">Contents</strong>
									</div>
									<div class="card-body">
										<div class="alert alert-success" role="alert">
											<h4 class="alert-heading">Well done!</h4>
											<p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so
												that you can see how spacing within an alert works with this kind of content.</p>
											<hr>
											<p class="mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
										</div>

										<div class="alert alert-warning" role="alert">
											<h4 class="alert-heading">Well done!</h4>
											<p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so
												that you can see how spacing within an alert works with this kind of content.</p>
											<hr>
											<p class="mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
										</div>

										<div class="alert alert-danger" role="alert">
											<h4 class="alert-heading">Well done!</h4>
											<p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so
												that you can see how spacing within an alert works with this kind of content.</p>
											<hr>
											<p class="mb-0">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
										</div>
									</div>
								</div>



							</div>
						</div>
						<div class="row">
								<div class="col-md-12">
										<div class="copyright">
												<p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
										</div>
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>


	</div>


</body>

</html>
<?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/dashboard/index.blade.php ENDPATH**/ ?>