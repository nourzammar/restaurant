<!DOCTYPE html>
<html>
<head>
  <title>واجهة المدير</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f7f7;
    }

    nav {
      background-color: #333;
      color: #fff;
      padding: 10px;
    }

    nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    nav ul li {
      display: inline-block;
      margin-right: 10px;
    }

    nav ul li a {
      color: #fff;
      text-decoration: none;
      padding: 5px 10px;
    }

    section {
      margin: 20px;
      background-color: #fff;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    table th,
    table td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    table th {
      background-color: #ff7f00;
      color: white;
    }

    .invoice {
      border: 1px solid #ddd;
      padding: 20px;
      margin-top: 20px;
    }

    .invoice h2 {
      margin-top: 0;
    }

    .invoice p {
      margin-bottom: 5px;
    }

    .thank-you {
      font-weight: bold;
    }
  </style>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>
  <nav>
    <ul>
      <li><a href="#order">Order</a></li>
      <li><a href="#reservation">Reservation</a></li>
      <li><a href="#bill">Bill</a></li>
      <li><a href="#warehouse">Warehouse</a></li>
      <li><a href="#kitchen">Kitchen</a></li>
    </ul>
  </nav>
  <form method="POST" action="<?php echo e(route('Manager.store')); ?>">
  <section id="order">
    <h2>Order</h2>
    <table>
      <thead>
        <tr>
          <th>Order Name</th>
          <th>Order Type</th>
          <th>Order Time</th>
          <th>Quantity</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
        <!-- قم بجلب البيانات من قاعدة البيانات وقم بتكرار الصفوف هنا -->
        <tr>
          <td>اسم الطلب</td>
          <td>نوع الطلب</td>
          <td>وقت الطلب</td>
          <td>الكمية</td>
          <td>السعر</td>
        </tr>
      </tbody>
    </table>
  </section>
</form>
  <section id="reservation">
    <h2>Reservation</h2>
    <table>
      <thead>
        <tr>
          <th>Customer Name</th>
          <th>Table Number</th>
          <th>Guest Number</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        <!-- قم بجلب البيانات من قاعدة البيانات وقم بتكرار الصفوف هنا -->
        <tr>
          <td>اسم الزبون</td>
          <td>رقم الطاولة</td>
          <td>عدد الضيوف</td>
          <td>الوقت</td>
        </tr>
      </tbody>
    </table>
  </section>

  <section id="bill">
    <h2>Bill</h2>
    <div class="invoice">
      <!-- قم بجلب بيانات الفاتورة من الطلب أو الحجز وقم بتكوين الفاتورة هنا -->
      <h2>رقم الفاتورة: 123</h2>
      <table>
        <thead>
          <tr>
            <th>اسم الوجبة</th>
            <th>السعر</th>
            <th>الكمية</th>
          </tr>
        </thead>
        <tbody>
          <!-- قم بتكرار الوجبات هنا -->
          <tr>
            <td>اسم الوجبة</td>
            <td>السعر</td>
            <td>الكمية</td>
          </tr>
        </tbody>
      </table>
      <p>الضريبة: 5 ريال</p>
      <p>السعر الإجمالي: 50 ريال</p>
      <p class="thank-you">شكرًا لزيارتكم!</p>
    </div>
  </section>

  <section id="warehouse">
    <h2>Warehouse</h2>
    <table>
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Quantity</th>
        </tr>
      </thead>
      <tbody>
        <!-- قم بجلب البيانات من قاعدة البيانات وقم بتكرار الصفوف هنا -->
        <tr>
          <td>اسم المنتج</td>
          <td>الكمية</td>
        </tr>
      </tbody>
    </table>
  </section>

  <section id="kitchen">
    <h2>Kitchen</h2>
    <table>
      <thead>
        <tr>
          <th>Order Name</th>
          <th>Order Type</th>
          <th>Order Time</th>
          <th>Quantity</th>
          <th>Price</th>
        </tr>
      </thead>
      <tbody>
        <!-- قم بجلب البيانات من قاعدة البيانات وقم بتكرار الصفوف هنا -->
        <tr>
          <td>اسم الطلب</td>
          <td>نوع الطلب</td>
          <td>وقت الطلب</td>
          <td>الكمية</td>
          <td>السعر</td>
        </tr>
      </tbody>
    </table>
  </section>
</body>
</html>
<?php /**PATH D:\Laravel\restaurant\resources\views/Manager.blade.php ENDPATH**/ ?>