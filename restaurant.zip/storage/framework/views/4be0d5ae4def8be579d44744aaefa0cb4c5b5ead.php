<h1>BILLS</h1>
<form method="POST" action="<?php echo e(route('users.store')); ?> ">
  <?php echo csrf_field(); ?>
  <input type="text" name="bills_id" placeholder="enter your id"> <br><br>
  <input type="text" name="orders_id"><br> <br>
  <input type="text" name="datetime"><br> <br>
  <input type="text" name="quantity	"><br><br>
  <input type="text" name="tax"><br><br>
  <button type="submit">submit  </button>
</form><?php /**PATH C:\Users\Asus\Desktop\restaurant\resources\views/bills.blade.php ENDPATH**/ ?>