<?php

use App\Http\Controllers\billController;
use App\Http\Controllers\ChefController;
use App\Http\Controllers\CustomAuthController;
use App\Http\Controllers\Dashboard\DashBillController;
use App\Http\Controllers\Dashboard\DashMealController;
use App\Http\Controllers\Dashboard\DashOrderController;
use App\Http\Controllers\Dashboard\ReserController;
use App\Http\Controllers\DineOutController;
use App\Http\Controllers\indexController;
use App\Http\Controllers\ItemMealController;
use App\Http\Controllers\ItemsController;
use App\Http\Controllers\MealController;
use App\Http\Controllers\orderController;
use App\Http\Controllers\reservationController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ManagerController;
use App\Http\Controllers\Dashboard\UsersController;
use App\Http\Controllers\EditMealController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
})->name('login');

Route::get('storage/{path}', function (Request $request) {
    try {
        $url = __DIR__ . '/../storage/app/public' . $request->path;
        $contents = file_get_contents($url);
        $file_info = new finfo(FILEINFO_MIME_TYPE);
        $mime_type = $file_info->buffer($contents);
        $response = Response::make($contents, 200);
        $response->headder('Content-type', $mime_type);
        return $response;
    } catch (\Exception $e) {
        abort(404);
    }
});

Route::resource('meal', MealController::class);


Route::resource('itemMeal', ItemMealController::class);
Route::resource('users', UserController::class);
Route::resource('bills', billController::class);
Route::resource('order', orderController::class);
Route::resource('dineout', DineOutController::class);
Route::resource('reservations', reservationController::class);
Route::resource('manager', ManagerController::class);
Route::resource('index', indexController::class);
Route::get('/chef', [ChefController::class, 'index'])->name('chef.index');
Route::post('/chef/store', [ChefController::class, 'store'])->name('chef.store');
Route::post('/chef/update', [ChefController::class, 'update'])->name('chef.update');
Route::post('/login/store', [CustomAuthController::class, 'login'])->name('CustomAuth.login');
Route::post('/login/reg', [CustomAuthController::class, 'register'])->name('CustomAuth.register');

Route::get('DashMeal', [DashMealController::class, 'index'])->name('DashMeal');
Route::get('DashMeal/edit/{id}', [DashMealController::class, 'edit'])->name('meal.edit');
Route::post('/EditMeal/{id}', [EditMealController::class, 'updateMeal'])->name('update');
Route::resource('DashWare', ItemsController::class);
Route::get('/DashUser', [UsersController::class, 'index'])->name('DashUser');
Route::get('/DashOrder', [DashOrderController::class, 'index'])->name('DashOrder');
Route::get('/DashRes', [ReserController::class, 'index'])->name('DashRes');
Route::get('/DashBill/{bill}', [DashBillController::class, 'index'])->name('DashBill');

// في web.php أو routes.php

// تحديث الوجبة
